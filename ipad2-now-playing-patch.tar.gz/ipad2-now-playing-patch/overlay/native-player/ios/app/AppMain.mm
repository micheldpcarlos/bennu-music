#include "AppAudioSession.inc"
// SPDX-License-Identifier: GPL-3.0-or-later
#import <UIKit/UIKit.h>
#include <pthread.h>
#include <cstdio>
#include <exception>
#include "NowPlaying.inc"

int ipad_cspot_engine_main(int argc, char** argv);

static void* runEngine(void*) {
  @autoreleasepool {
    char name[] = "ipad-media-player";
    char bitrate[] = "-b";
    char value[] = "160";
    char* arguments[] = {name, bitrate, value, nullptr};
    ipad_player_waiting();
    try {
      int result = ipad_cspot_engine_main(3, arguments);
      std::fprintf(stderr, "APP: engine returned %d\n", result);
      ipad_player_failed(result ? "The player could not connect." : "The player stopped.");
    } catch (const std::exception& error) {
      std::fprintf(stderr, "APP: engine exception: %s\n", error.what());
      ipad_player_failed(error.what());
    } catch (...) {
      std::fprintf(stderr, "APP: engine failed with unknown exception\n");
      ipad_player_failed("The player encountered an unexpected error.");
    }
  }
  return nullptr;
}

@interface IPadPlayerDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic, strong) UIWindow* window;
@end

@implementation IPadPlayerDelegate
- (void)audioSessionEvent:(NSNotification*)notification {
  std::fprintf(stderr, "SESSION: notification=%s info=%s\n",
      notification.name.UTF8String, notification.userInfo.description.UTF8String);
  ipadLogAudioSession();
}

- (BOOL)application:(UIApplication*)application
    didFinishLaunchingWithOptions:(NSDictionary*)options {
  (void)application;
  (void)options;
  NSString* documents = NSSearchPathForDirectoriesInDomains(
      NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
  NSString* log = [documents stringByAppendingPathComponent:@"cspot-app.log"];
  std::freopen(log.fileSystemRepresentation, "a", stdout);
  std::freopen(log.fileSystemRepresentation, "a", stderr);
  std::setvbuf(stdout, nullptr, _IOLBF, 0);
  std::setvbuf(stderr, nullptr, _IOLBF, 0);
  std::fprintf(stderr, "APP: launched; log=%s\n", log.fileSystemRepresentation);

  self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
  NowPlayingController* controller = [[NowPlayingController alloc] init];
  self.window.rootViewController = controller;
  [self.window makeKeyAndVisible];

  NSNotificationCenter* center = NSNotificationCenter.defaultCenter;
  [center addObserver:self selector:@selector(audioSessionEvent:)
      name:AVAudioSessionInterruptionNotification object:nil];
  [center addObserver:self selector:@selector(audioSessionEvent:)
      name:AVAudioSessionRouteChangeNotification object:nil];
  pthread_t worker;
  int result = pthread_create(&worker, nullptr, runEngine, nullptr);
  if (result == 0) pthread_detach(worker);
  else {
    std::fprintf(stderr, "APP: worker creation failed: %d\n", result);
    ipad_player_failed("The player could not start.");
  }
  return YES;
}
- (void)applicationDidEnterBackground:(UIApplication*)application {
  (void)application;
  std::fprintf(stderr, "APP: entered background\n");
  ipadLogAudioSession();
}
- (void)applicationDidBecomeActive:(UIApplication*)application {
  (void)application;
  std::fprintf(stderr, "APP: became active\n");
  ipadLogAudioSession();
}
@end

int main(int argc, char** argv) {
  @autoreleasepool {
    return UIApplicationMain(argc, argv, nil,
        NSStringFromClass([IPadPlayerDelegate class]));
  }
}
